package com.example.entertoparkingwithoutspecifiedspot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnterToParkingWithoutSpecifiedSpotApplication {

    public static void main(String[] args) {
        SpringApplication.run(EnterToParkingWithoutSpecifiedSpotApplication.class, args);
    }

}
