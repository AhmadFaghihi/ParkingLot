package com.example.entertoparkingwithoutspecifiedspot.controllers;

import com.example.entertoparkingwithoutspecifiedspot.model.entities.account.Admin;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.account.Attendant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/")
public class AccountController {

    private Admin admin;
    private Attendant attendant;

    @Autowired
    public void setAttendant(Attendant attendant) {
        this.attendant = attendant;
    }

    @Autowired
    public void setAdmin(Admin admin) {
        this.admin = admin;
    }

    @GetMapping("/")
    public String loginPage() {

        return "login";
    }

    @GetMapping("/homeAdmin")
    public String homeAd() {

        return "homeAdmin";
    }

    @GetMapping("/homeAttendant")
    public String homeAt() {

        return "homeAttendant";
    }

    @PostMapping(value = "/account", params = {"username=Admin"})
    public String homeAdmin(@RequestParam String password) {
        if (admin.getAdminPassword().contains(password)) {
            return "homeAdmin";
        }
        return "redirect:/";
    }

    @PostMapping(value = "/account", params = {"username=Attendant"})
    public String homeAttendant(@RequestParam String password) {
        if (attendant.getAttendantPassword().contains(password)) {
            return "homeAttendant";
        }
        return "redirect:/";
    }

}
