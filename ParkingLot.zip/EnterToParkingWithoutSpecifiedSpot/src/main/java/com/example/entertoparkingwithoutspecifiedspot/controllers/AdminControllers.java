package com.example.entertoparkingwithoutspecifiedspot.controllers;

import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingFloor.ParkingFloor;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingLot.ParkingLot;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingSpot.ParkingSpot;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingSpot.ParkingSpotType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")

public class AdminControllers {
    private final ParkingLot parkingLot=ParkingLot.getInstance();

    @GetMapping("/addFloor")
    public String floorPage(Model model) {

        model.addAttribute("floor",new ParkingFloor());

        return "admin_addFloor";
    }

    @PostMapping("/reviewFloor")
    public String reviewFloor(@ModelAttribute ParkingFloor floor, HttpServletRequest request) {

        HttpSession session = request.getSession();
        session.setAttribute("floor", floor);

        return "admin_floor_review";
    }

    @GetMapping("/addFloorToParking")
    public String addFloorToParking(@SessionAttribute ParkingFloor floor, SessionStatus status) {
        // add floor to parking
        System.out.println();
        System.out.println("floors in lot before add : "+parkingLot.getParkingFloors().keySet());
        System.out.println();

        floor.setName(String.valueOf(parkingLot.getParkingFloors().size()+1));
        System.out.println();
        System.out.println("floor after review : "+floor);

        System.out.println();
        parkingLot.addParkingFloor(floor);
        status.setComplete();

        System.out.println();
        System.out.println("floors in lot after add : "+parkingLot.getParkingFloors().keySet());
        System.out.println();
        return "redirect:/homeAdmin";
    }


    @GetMapping("/addSpot")
    public String spotPage() {
        return "admin_addSpot";
    }

    @PostMapping("/reviewSpot")
    public String reviewSpot(HttpServletRequest request,
                             @RequestParam ParkingSpotType spotType,
                             @RequestParam String floorOfSpot) {

        HttpSession session = request.getSession();
        session.setAttribute("spotType", spotType);
        session.setAttribute("floorOfSpot", floorOfSpot);

        return "admin_spot_review";
    }

    @GetMapping("/addSpotToFloor")
    public String addSpotToFloor(@SessionAttribute ParkingSpotType spotType,
                                 @SessionAttribute String floorOfSpot,
                                 SessionStatus status) {
        // add spot to floor
        ParkingFloor spotFloor = parkingLot.getParkingFloors().get(floorOfSpot);
        ParkingSpot newSpot = spotFloor.getNewSpot(spotType);
        spotFloor.addParkingSpot(newSpot);
        status.setComplete();
        return "redirect:/homeAdmin";
    }

}
