package com.example.entertoparkingwithoutspecifiedspot.controllers;

import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingLot.ParkingLot;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingTicket.ParkingTicket;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle.VehicleType;
import com.example.entertoparkingwithoutspecifiedspot.parking.ParkingAttendantPortal;
import com.example.entertoparkingwithoutspecifiedspot.parking.ParkingSystem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Arrays;
import java.util.LinkedList;

@Controller
@RequestMapping("/attendant")
public class AttendantController {
    private ParkingSystem parkingSystem;
    @Autowired
    public void setParkingSystem(ParkingSystem parkingSystem) {
        this.parkingSystem = parkingSystem;
    }

    private final ParkingLot parkingLot = ParkingLot.getInstance();
    ParkingAttendantPortal attendantPortal = parkingLot.getParkingAttendantPortal();


    @GetMapping("/parkForm")
    public String parkForm() {
        return "attendant_parkForm";
    }

    @PostMapping("/reviewParkForm")
    public String reviewParkForm(HttpServletRequest request,
                                 @RequestParam String licenseNumber,
                                 @RequestParam VehicleType type,
                                 @RequestParam boolean handicapped) {
        // Review ParkForm
        HttpSession session = request.getSession();
        session.setAttribute("licenseNumber", licenseNumber);
        session.setAttribute("type", type);
        session.setAttribute("handicapped", handicapped);

        return "reviewPark";
    }

    @GetMapping("/ticket")
    public String ticket(HttpServletRequest request,
                         @SessionAttribute String licenseNumber,
                         @SessionAttribute VehicleType type,
                         @SessionAttribute boolean handicapped) {
        // park vehicle
        ParkingTicket parkingTicket = parkingSystem.parkVehicle(licenseNumber, type, handicapped);
        HttpSession session = request.getSession();
        session.setAttribute("parkingTicket", parkingTicket);
        session.setAttribute("handicapped", handicapped);

        return "ticket1";
    }

    @GetMapping("/print")
    public String print(@SessionAttribute ParkingTicket parkingTicket,
                        @SessionAttribute boolean handicapped) {
        return "redirect:/homeAttendant";
    }

    @GetMapping("/unpark")
    public String vehicleInfo() {
        return "vehicleInfo";
    }

    @PostMapping("/getInfo")
    public String getInfo(@RequestParam String licenseNumber,
                          @RequestParam boolean hasTicket, Model model) {

        ParkingTicket scanTicket = this.parkingLot.scanTicket(licenseNumber, hasTicket);

        System.out.println();
        System.out.println("scanTicket in get info: " + scanTicket);
        System.out.println();

        this.attendantPortal.setParkingTicket(scanTicket);

        System.out.println();
        System.out.println("attendantPortal after park :" + this.attendantPortal);
        System.out.println();

        model.addAttribute("unparkPortal", this.attendantPortal);
        model.addAttribute("RadioOptions", new LinkedList<>(Arrays.asList("Yes", "No")));

        return "bill";
    }

    @PostMapping("/payTicket")
    public String payTicket(@ModelAttribute ParkingAttendantPortal unparkPortal) {

        this.attendantPortal.setPayWithCard(unparkPortal.isPayWithCard());
        this.attendantPortal.getCashTransaction().setCashTendered(unparkPortal.getCashTransaction().getCashTendered());
        this.attendantPortal.getCardTransaction().setNameOnCard(unparkPortal.getCardTransaction().getNameOnCard());

        boolean Successfully;
        if (unparkPortal.isPayWithCard()) {
            Successfully = this.parkingLot.
                    getPaymentWithCard(this.attendantPortal.getParkingTicket(), unparkPortal.getCardTransaction().getNameOnCard());
        } else
            Successfully = parkingSystem.getParkingLot().
                    getPaymentWithCash(this.attendantPortal.getParkingTicket(), unparkPortal.getCashTransaction().getCashTendered());


        if (Successfully) {

            parkingSystem.unparkVehicleBtn(this.attendantPortal.getParkingTicket());
            return "goodBye";
        }
        return "failUnPark";
    }

    @GetMapping("/payAgain")
    public String payAgain(Model model) {
        model.addAttribute("unparkPortal", this.attendantPortal);
        return "payAgain";
    }

    @GetMapping("/confirmAgain")
    public String confirmAgain() {

        boolean Successfully;
        if (this.attendantPortal.isPayWithCard()) {
            Successfully = this.parkingLot.
                    getPaymentWithCard(this.attendantPortal.getParkingTicket(), this.attendantPortal.getCardTransaction().getNameOnCard());
        } else
            Successfully = this.parkingLot.
                    getPaymentWithCash(this.attendantPortal.getParkingTicket(), this.attendantPortal.getCashTransaction().getCashTendered());


        if (Successfully) {

            parkingSystem.unparkVehicleBtn(this.attendantPortal.getParkingTicket());
            return "goodBye";
        }

        return "failUnpark";
    }


}
