package com.example.entertoparkingwithoutspecifiedspot.model.entities.account;

import lombok.Data;

@Data
public abstract class Account {
    private String userName;
    private String password;
    private AccountStatus status;
    private Person person;

    public boolean resetPassword(){
        this.password=null;
        return true;
    }
}
