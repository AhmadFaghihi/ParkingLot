package com.example.entertoparkingwithoutspecifiedspot.model.entities.account;

public enum AccountStatus {
    ACTIVE, BLOCKED, BANNED, COMPROMISED, ARCHIVED, UNKNOWN
}
