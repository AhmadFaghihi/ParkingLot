package com.example.entertoparkingwithoutspecifiedspot.model.entities.account;

import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
public class Address {
    private String streetAddress;
    private String city;
    private String state;
    private String zipCode;
    private String country;
}
