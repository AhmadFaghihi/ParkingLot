package com.example.entertoparkingwithoutspecifiedspot.model.entities.account;

import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
@Component
public class Admin extends Account {

    private Set<String> adminPassword = Collections.
            synchronizedSet(new HashSet(List.of("admin", "admin1")));

}

