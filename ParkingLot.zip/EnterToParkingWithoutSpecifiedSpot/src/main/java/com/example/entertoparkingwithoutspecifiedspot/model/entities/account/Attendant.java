package com.example.entertoparkingwithoutspecifiedspot.model.entities.account;

import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
@Component
public class Attendant extends Account {

    private Set<String> attendantPassword =
            Collections.synchronizedSet(new HashSet(List.of("123", "456")));

    //public  boolean processTicket(String TicketNumber);
}
