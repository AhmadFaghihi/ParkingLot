package com.example.entertoparkingwithoutspecifiedspot.model.entities.account;

import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
public class Person {
    private String name;
    private Address address;
    private String email;
    private String phone;
}
