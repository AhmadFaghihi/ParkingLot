package com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingDisplayBoard;

import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingSpot.*;
import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
public class ParkingDisplayBoard {

    private String id;
    private String floorOfDisplayBoard;
    private HandicappedSpot handicappedFreeSpot;
    private CompactSpot compactFreeSpot;
    private LargeSpot largeFreeSpot;
    private MotorbikeSpot motorbikeFreeSpot;
    private ElectricSpot electricFreeSpot;

    public void showEmptySpotNumber() {
        System.out.println();
        String message = "";

        if (handicappedFreeSpot == null) {
            message += "This floor does not have Handicapped Spots";
        } else if (!handicappedFreeSpot.isFull()) {
            message += "Free Handicapped: " + handicappedFreeSpot.getNumber();
        } else {
            message += "Handicapped is full";
        }

        message += System.lineSeparator();

        if (compactFreeSpot == null) {
            message += "This floor does not have Compact Spots";
        } else if (!compactFreeSpot.isFull()) {
            message += "Free Compact: " + compactFreeSpot.getNumber();
        } else {
            message += "Compact is full";
        }

        message += System.lineSeparator();

        if (largeFreeSpot == null) {
            message += "This floor does not have Large Spots";
        } else if (!largeFreeSpot.isFull()) {
            message += "Free Large: " + largeFreeSpot.getNumber();
        } else {
            message += "Large is full";
        }

        message += System.lineSeparator();

        if (motorbikeFreeSpot == null) {
            message += "This floor does not have Motorbike Spots";
        } else if (!motorbikeFreeSpot.isFull()) {
            message += "Free Motorbike: " + motorbikeFreeSpot.getNumber();
        } else {
            message += "Motorbike is full";
        }

        message += System.lineSeparator();

        if (electricFreeSpot == null) {
            message += "This floor does not have Electric Spots";
        } else if (!electricFreeSpot.isFull()) {
            message += "Free Electric: " + electricFreeSpot.getNumber();
        } else {
            message += "Electric is full";
        }

        System.out.println(message);
        System.out.println();

    }

}
