package com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingFloor;

import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingDisplayBoard.ParkingDisplayBoard;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingSpot.*;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle.Vehicle;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle.VehicleType;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.function.Predicate;
import java.util.function.Supplier;

import static com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingSpot.ParkingSpotType.*;
import static com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle.VehicleType.TRUCK;
import static com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle.VehicleType.VAN;

@Data
@Component
public class ParkingFloor {
    private String name;
    private int weightCapacity;
    private double heightCapacity;
    private int totalHandicappedSpots;
    private int totalElectricSpots;
    private int totalCompactSpots;
    private int totalLargeSpots;
    private int totalMotorbikeSpots;
    private int totalSpots;

    public ParkingFloor(String name,
                        int weightCapacity,
                        double heightCapacity,
                        int totalHandicappedSpots,
                        int totalElectricSpots,
                        int totalCompactSpots,
                        int totalLargeSpots,
                        int totalMotorbikeSpots) {
        this.name = name;
        this.weightCapacity = weightCapacity;
        this.heightCapacity = heightCapacity;
        this.totalHandicappedSpots = totalHandicappedSpots;
        this.totalElectricSpots = totalElectricSpots;
        this.totalCompactSpots = totalCompactSpots;
        this.totalLargeSpots = totalLargeSpots;
        this.totalMotorbikeSpots = totalMotorbikeSpots;
        initialize();
    }

    public ParkingFloor() {
    }

    private int largeSpotCount;
    private int motorbikeSpotCount;
    private int compactSpotCount;
    private int electricSpotCount;
    private int handicappedSpotCount;

    private int freeCompactSpotCount;
    private int freeLargeSpotCount;
    private int freeMotorbikeSpotCount;
    private int freeElectricSpotCount;
    private int freeHandicappedSpotCount;

    private int weight;

    private HashMap<String, HandicappedSpot> handicappedSpots;
    private HashMap<String, CompactSpot> compactSpots;
    private HashMap<String, LargeSpot> largeSpots;
    private HashMap<String, MotorbikeSpot> motorbikeSpots;
    private HashMap<String, ElectricSpot> electricSpots;
    private HashMap<String, ParkingSpot> spots;

    //AutoWired must init
    private ParkingDisplayBoard displayBoard;

    public ParkingSpot assignVehicleToSpot(Vehicle vehicle, List<ParkingSpot> spots) {

        if (!spots.isEmpty()) {

            ParkingSpot spotOfVehicle = getFirstFreeSpot(spots);

            boolean Success = spotOfVehicle.assignVehicle(vehicle);

            if (Success) {
                incrementSpotCount(vehicle.getType());
                incrementWeight(vehicle.getType());

                switch (spotOfVehicle.getType()) {
                    case HANDICAPPED -> updateDisplayBoardForHandicapped(spotOfVehicle);
                    case COMPACT -> updateDisplayBoardForCompact(spotOfVehicle);
                    case LARGE -> updateDisplayBoardForLarge(spotOfVehicle);
                    case MOTORBIKE -> updateDisplayBoardForMotorbike(spotOfVehicle);
                    case ELECTRIC -> updateDisplayBoardForElectric(spotOfVehicle);
                    default -> System.out.println("Wrong parking spot type!");
                }

                return spotOfVehicle;
            }
        }
        return null;
    }

    public void freeSpot(ParkingSpot spot) {

        spot.removeVehicle();
        switch (spot.getType()) {
            case HANDICAPPED -> freeHandicappedSpotCount++;
            case COMPACT -> freeCompactSpotCount++;
            case LARGE -> freeLargeSpotCount++;
            case MOTORBIKE -> freeMotorbikeSpotCount++;
            case ELECTRIC -> freeElectricSpotCount++;
            default -> System.out.println("Wrong parking spot type!");
        }
    }

    private ParkingSpot getFirstFreeSpot(List<ParkingSpot> spots) {

        return spots.stream().min(Comparator.comparing(ParkingSpot::getType)).orElse(null);
    }

    private void incrementWeight(VehicleType type) {
        switch (type) {
            case TRUCK -> this.weight += VehicleType.TRUCK.getWeightNeeded();
            case VAN -> this.weight += VehicleType.VAN.getWeightNeeded();
            case CAR -> this.weight += VehicleType.CAR.getWeightNeeded();
            case MOTORBIKE -> this.weight += VehicleType.MOTORBIKE.getWeightNeeded();
            case ELECTRIC -> this.weight += VehicleType.ELECTRIC.getWeightNeeded();
        }
    }

    public void decrementWeight(VehicleType type) {

        switch (type) {
            case TRUCK -> this.weight -= VehicleType.TRUCK.getWeightNeeded();
            case VAN -> this.weight -= VehicleType.VAN.getWeightNeeded();
            case CAR -> this.weight -= VehicleType.CAR.getWeightNeeded();
            case MOTORBIKE -> this.weight -= VehicleType.MOTORBIKE.getWeightNeeded();
            case ELECTRIC -> this.weight -= VehicleType.ELECTRIC.getWeightNeeded();
        }
    }

    private void incrementSpotCount(VehicleType type) {
        if (type == TRUCK || type == VAN) {
            largeSpotCount++;
        } else if (type == VehicleType.MOTORBIKE) {
            motorbikeSpotCount++;
        } else if (type == VehicleType.CAR) {
            if (!isCompactSpotFull.get()) {
                compactSpotCount++;
            } else {
                largeSpotCount++;
            }
        } else { // electric car
            if (!isElectricSpotFull.get()) {
                electricSpotCount++;
            } else if (!isCompactSpotFull.get()) {
                compactSpotCount++;
            } else {
                largeSpotCount++;
            }
        }

    }

    public boolean isAllSpotsFull(VehicleType type) {

        // trucks and vans can only be parked in LargeSpot
        if ((type == TRUCK) || (type == VAN)) {
            return (isTruckOrVanCapacityFull).test(type);
        }
        // motorbikes can only be parked at motorbike spots
        if (type == VehicleType.MOTORBIKE) {
            return (isMotorbikeCapacityFull).test(type);
        }
        // cars can be parked at compact or large spots
        if (type == VehicleType.CAR) {
            return (isCarCapacityFull).test(type);
        }
        // electric car can be parked at compact, large or electric spots
        return (isElectricCapacityFull).test(type);
    }

    public boolean isWeightOrHeightCapacityOfFloorFull(VehicleType type) {

        Predicate<VehicleType> isWeightCapacityFull = i -> (this.weight + type.getWeightNeeded() > this.weightCapacity);
        Predicate<VehicleType> isHeightCapacityFull = i -> (type.getHeightNeeded() > this.heightCapacity);

        if ((type == VehicleType.TRUCK)) {
            return isWeightCapacityFull.or(isHeightCapacityFull).test(type);
        }
        if (type == VehicleType.VAN) {
            return isWeightCapacityFull.or(isHeightCapacityFull).test(type);
        }
        if (type == VehicleType.MOTORBIKE) {
            return isWeightCapacityFull.or(isHeightCapacityFull).test(type);
        }
        if (type == VehicleType.CAR) {
            return isWeightCapacityFull.or(isHeightCapacityFull).test(type);
        }
        return isWeightCapacityFull.or(isHeightCapacityFull).test(type);
    }

    public void addParkingSpot(ParkingSpot spot) {

        switch (spot.getType()) {
            case HANDICAPPED -> handicappedSpots.put(spot.getNumber(), (HandicappedSpot) spot);
            case COMPACT -> compactSpots.put(spot.getNumber(), (CompactSpot) spot);
            case LARGE -> largeSpots.put(spot.getNumber(), (LargeSpot) spot);
            case MOTORBIKE -> motorbikeSpots.put(spot.getNumber(), (MotorbikeSpot) spot);
            case ELECTRIC -> electricSpots.put(spot.getNumber(), (ElectricSpot) spot);
            default -> System.out.println("Wrong parking spot type!");
        }
    }

    private void updateDisplayBoardForHandicapped(ParkingSpot spot) {
        if (this.displayBoard.getHandicappedFreeSpot().getNumber().equals(spot.getNumber())) {
            // find another free handicapped parking and assign to displayBoard
            handicappedSpots.values().stream().
                    filter(handicappedSpot -> !handicappedSpot.isFull()).
                    min(Comparator.comparing(ParkingSpot::getNumber)).
                    ifPresent(handicappedSpot -> this.displayBoard.setHandicappedFreeSpot(handicappedSpot));

            this.displayBoard.showEmptySpotNumber();
        }
    }

    private void updateDisplayBoardForMotorbike(ParkingSpot spot) {
        if (this.displayBoard.getMotorbikeFreeSpot().getNumber().equals(spot.getNumber())) {

            motorbikeSpots.values().stream().
                    filter(motorbikeSpot -> !motorbikeSpot.isFull()).
                    min(Comparator.comparing(ParkingSpot::getNumber)).
                    ifPresent(motorbikeSpot -> this.displayBoard.setMotorbikeFreeSpot(motorbikeSpot));

            this.displayBoard.showEmptySpotNumber();
        }
    }

    private void updateDisplayBoardForLarge(ParkingSpot spot) {
        if (displayBoard.getLargeFreeSpot().getNumber().equals(spot.getNumber())) {

            largeSpots.values().stream().
                    filter(largeSpot -> !largeSpot.isFull()).
                    min(Comparator.comparing(ParkingSpot::getNumber)).
                    ifPresent(largeSpot -> this.displayBoard.setLargeFreeSpot(largeSpot));

            displayBoard.showEmptySpotNumber();
        }
    }

    private void updateDisplayBoardForElectric(ParkingSpot spot) {
        if (this.displayBoard.getElectricFreeSpot().getNumber().equals(spot.getNumber())) {

            electricSpots.values().stream().
                    filter(electricSpot -> !electricSpot.isFull()).
                    min(Comparator.comparing(ParkingSpot::getNumber)).
                    ifPresent(electricSpot -> this.displayBoard.setElectricFreeSpot(electricSpot));

            this.displayBoard.showEmptySpotNumber();
        }
    }

    private void updateDisplayBoardForCompact(ParkingSpot spot) {
        if (this.displayBoard.getCompactFreeSpot().getNumber().equals(spot.getNumber())) {

            compactSpots.values().stream().
                    filter(compactSpot -> !compactSpot.isFull()).
                    min(Comparator.comparing(ParkingSpot::getNumber)).
                    ifPresent(compactSpot -> this.displayBoard.setCompactFreeSpot(compactSpot));

            this.displayBoard.showEmptySpotNumber();
        }

    }

    public List<ParkingSpot> findSpotsToFitVehicle(Vehicle vehicle) {

        List<ParkingSpot> freeSpots = new ArrayList<>();

        if (vehicle.isHandicapped()) {
            freeSpots.add(findHandicappedSpotsToFitVehicle());
        }
        // trucks and vans can only be parked in LargeSpot
        if ((vehicle.getType() == TRUCK) || (vehicle.getType() == VAN)) {

            freeSpots.add(findLargeSpotsToFitVehicle());
        }
        // motorbikes can only be parked at motorbike spots
        if (vehicle.getType() == VehicleType.MOTORBIKE) {

            freeSpots.add(findMotorbikeSpotsToFitVehicle());
        }
        // cars can be parked at compact or large spots
        if (vehicle.getType() == VehicleType.CAR) {

            freeSpots.add(findCompactSpotsToFitVehicle());
            freeSpots.add(findLargeSpotsToFitVehicle());

        }
        // electric car can be parked at compact, large or electric spots
        if (vehicle.getType() == VehicleType.ELECTRIC) {

            freeSpots.add(findElectricSpotsToFitVehicle());
            freeSpots.add(findCompactSpotsToFitVehicle());
            freeSpots.add(findLargeSpotsToFitVehicle());

        }

        return freeSpots.stream().filter(Objects::nonNull).toList();
    }

    private ParkingSpot findLargeSpotsToFitVehicle() {

        Optional<LargeSpot> largeSpotOptional = largeSpots.values().stream().
                filter(largeSpot -> !largeSpot.isFull()).
                min(Comparator.comparing(ParkingSpot::getNumber));

        return largeSpotOptional.orElse(null);

    }

    private ParkingSpot findCompactSpotsToFitVehicle() {

        Optional<CompactSpot> compactSpotOptional = compactSpots.values().stream().
                filter(compactSpot -> !compactSpot.isFull()).
                min(Comparator.comparing(ParkingSpot::getNumber));

        return compactSpotOptional.orElse(null);
    }

    private ParkingSpot findMotorbikeSpotsToFitVehicle() {

        Optional<MotorbikeSpot> motorbikeSpotOptional = motorbikeSpots.values().stream().
                filter(motorbikeSpot -> !motorbikeSpot.isFull()).
                min(Comparator.comparing(ParkingSpot::getNumber));

        return motorbikeSpotOptional.orElse(null);
    }

    private ParkingSpot findElectricSpotsToFitVehicle() {

        Optional<ElectricSpot> electricSpotOptional = electricSpots.values().stream().
                filter(electricSpot -> !electricSpot.isFull()).
                min(Comparator.comparing(ParkingSpot::getNumber));

        return electricSpotOptional.orElse(null);
    }

    private ParkingSpot findHandicappedSpotsToFitVehicle() {

        Optional<HandicappedSpot> handicappedSpotOptional = handicappedSpots.values().stream().
                filter(handicappedSpot -> !handicappedSpot.isFull()).
                min(Comparator.comparing(ParkingSpot::getNumber));

        return handicappedSpotOptional.orElse(null);
    }

    public ParkingSpot getNewSpot(ParkingSpotType parkingSpotType) {

        if (Objects.equals(parkingSpotType, ParkingSpotType.HANDICAPPED)) {
            HandicappedSpot handicappedSpot = new HandicappedSpot();
            handicappedSpot.setNumber("H" + (totalHandicappedSpots + 1));
            totalHandicappedSpots++;
            totalSpots++;
            return handicappedSpot;
        }
        if (Objects.equals(parkingSpotType, ParkingSpotType.COMPACT)) {
            CompactSpot compactSpot = new CompactSpot();
            compactSpot.setNumber("H" + (totalCompactSpots + 1));
            totalCompactSpots++;
            totalSpots++;
            return compactSpot;
        }
        if (Objects.equals(parkingSpotType, ParkingSpotType.LARGE)) {
            LargeSpot largeSpot = new LargeSpot();
            largeSpot.setNumber("L" + (totalLargeSpots + 1));
            totalLargeSpots++;
            totalSpots++;
            return largeSpot;
        }
        if (Objects.equals(parkingSpotType, ParkingSpotType.MOTORBIKE)) {
            MotorbikeSpot motorbikeSpot = new MotorbikeSpot();
            motorbikeSpot.setNumber("M" + (totalMotorbikeSpots + 1));
            totalMotorbikeSpots++;
            return motorbikeSpot;
        }
        if (Objects.equals(parkingSpotType, ParkingSpotType.ELECTRIC)) {
            ElectricSpot electricSpot = new ElectricSpot();
            electricSpot.setNumber("E" + (totalElectricSpots + 1));
            totalElectricSpots++;
            totalSpots++;
            return electricSpot;
        }

        return null;
    }

    public HashMap<String, HandicappedSpot> initHandicappedSpots(int totalHandicappedSpots) {

        handicappedSpots = new HashMap<>();
        for (int i = 1; i <= totalHandicappedSpots; i++) {
            HandicappedSpot spot = new HandicappedSpot();
            spot.setNumber("#H" + i);
            handicappedSpots.put(spot.getNumber(), spot);
        }
        return handicappedSpots;
    }

    public HashMap<String, CompactSpot> initCompactSpots(int totalCompactSpots) {

        compactSpots = new HashMap<>();
        for (int i = 1; i <= totalCompactSpots; i++) {
            CompactSpot spot = new CompactSpot();
            spot.setNumber("#C" + i);
            compactSpots.put(spot.getNumber(), spot);
        }
        return compactSpots;
    }

    public HashMap<String, MotorbikeSpot> initMotorbikeSpots(int totalMotorbikeSpots) {

        motorbikeSpots = new HashMap<>();
        for (int i = 1; i <= totalMotorbikeSpots; i++) {
            MotorbikeSpot spot = new MotorbikeSpot();
            spot.setNumber("#M" + i);
            motorbikeSpots.put(spot.getNumber(), spot);
        }
        return motorbikeSpots;
    }

    public HashMap<String, ElectricSpot> initElectricSpots(int totalElectricSpots) {

        electricSpots = new HashMap<>();
        for (int i = 1; i <= totalElectricSpots; i++) {
            ElectricSpot spot = new ElectricSpot();
            spot.setNumber("#E" + i);
            electricSpots.put(spot.getNumber(), spot);
        }
        return electricSpots;
    }

    public HashMap<String, LargeSpot> initLargeSpots(int totalLargeSpots) {

        largeSpots = new HashMap<>();
        for (int i = 1; i <= totalLargeSpots; i++) {
            LargeSpot spot = new LargeSpot();
            spot.setNumber("#L" + i);
            largeSpots.put(spot.getNumber(), spot);
        }
        return largeSpots;
    }

    public HashMap<String, ParkingSpot> initSpots() {

        spots = new HashMap<>();

        spots.putAll(handicappedSpots);
        spots.putAll(compactSpots);
        spots.putAll(motorbikeSpots);
        spots.putAll(electricSpots);
        spots.putAll(largeSpots);

        return spots;
    }


    public void initialize() {

        totalSpots=(totalHandicappedSpots+ totalCompactSpots+
                totalLargeSpots+ totalMotorbikeSpots+totalElectricSpots);

        freeCompactSpotCount = totalCompactSpots - compactSpotCount;
        freeLargeSpotCount = totalLargeSpots - largeSpotCount;
        freeMotorbikeSpotCount = totalMotorbikeSpots - motorbikeSpotCount;
        freeElectricSpotCount = totalElectricSpots - electricSpotCount;
        freeHandicappedSpotCount = totalHandicappedSpots - handicappedSpotCount;

        this.handicappedSpots = initHandicappedSpots(totalHandicappedSpots);
        this.compactSpots = initCompactSpots(totalCompactSpots);
        this.largeSpots = initLargeSpots(totalLargeSpots);
        this.motorbikeSpots = initMotorbikeSpots(totalMotorbikeSpots);
        this.electricSpots = initElectricSpots(totalElectricSpots);
        this.spots = initSpots();

        this.displayBoard = new ParkingDisplayBoard();
        displayBoard.setFloorOfDisplayBoard(this.name);
        displayBoard.setHandicappedFreeSpot(handicappedSpots.get("#H1"));
        displayBoard.setCompactFreeSpot(compactSpots.get("#C1"));
        displayBoard.setElectricFreeSpot(electricSpots.get("#E1"));
        displayBoard.setLargeFreeSpot(largeSpots.get("#L1"));
        displayBoard.setMotorbikeFreeSpot(motorbikeSpots.get("#M1"));

    }

    Predicate<VehicleType> isTruckOrVanCapacityFull = TruckOrVan -> largeSpots.values().stream().allMatch(ParkingSpot::isFull);
    Predicate<VehicleType> isMotorbikeCapacityFull = MOTORBIKE -> motorbikeSpots.values().stream().allMatch(ParkingSpot::isFull);
    Predicate<VehicleType> isCarCapacityFull = CAR -> spots.values().stream()
            .filter(s -> s.getType() != MOTORBIKE)
            .filter(z -> z.getType() != ELECTRIC).
            filter(x -> x.getType() != HANDICAPPED).
            allMatch(ParkingSpot::isFull);
    Predicate<VehicleType> isElectricCapacityFull = Electric -> spots.values().stream()
            .filter(s -> s.getType() != MOTORBIKE)
            .filter(x -> x.getType() != HANDICAPPED).
            allMatch(ParkingSpot::isFull);

    Supplier<Boolean> isCompactSpotFull = () -> compactSpotCount >= totalCompactSpots;
    Supplier<Boolean> isElectricSpotFull = () -> electricSpotCount >= totalElectricSpots;


}


