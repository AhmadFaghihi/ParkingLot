package com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingLot;

import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingFloor.ParkingFloor;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingRate.ParkingRate;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingSpot.ParkingSpot;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingTicket.ParkingTicket;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingTicket.ParkingTicketStatus;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.payment.CardTransaction;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.payment.CashTransaction;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.payment.Payment;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.payment.PaymentStatus;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle.Vehicle;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle.VehicleType;
import com.example.entertoparkingwithoutspecifiedspot.parking.ParkingAttendantPortal;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

@Data
public class ParkingLot {
    private String name;
    private int numberOfFloors;
    private boolean gate = false;
    private int maxCompactCount;
    private int maxHandicappedCount;
    private int maxLargeCount;
    private int maxMotorbikeCount;
    private int maxElectricCount;
    private ParkingRate parkingRate;
    private ParkingAttendantPortal parkingAttendantPortal;

    private HashMap<String, ParkingFloor> parkingFloors;

    private HashMap<String, ParkingTicket> activeTickets = new HashMap<>();
    private HashMap<String, Payment> payments = new HashMap<>();

    public boolean unparkVehicle(ParkingTicket modifiedParkingTicket) {

        if (modifiedParkingTicket.getStatus() == ParkingTicketStatus.PAID) {

            ParkingFloor floorOfVehicle = findFloorOfVehicle(modifiedParkingTicket.getTicketNumber());
            ParkingSpot spotOfVehicle = findSpotOfVehicle(modifiedParkingTicket.getTicketNumber());

            floorOfVehicle.freeSpot(spotOfVehicle);
            floorOfVehicle.decrementWeight(modifiedParkingTicket.getVehicleType());

            unregisterParkingTicket(modifiedParkingTicket);
            this.gate = true;
            return true;
        }

        return false;
    }

    public synchronized ParkingTicket getNewParkingTicket(Vehicle vehicle) {

        Optional<ParkingFloor> freeFloor = getFirstFreeFloor(vehicle);

        List<ParkingSpot> freeSpots = getFirstFreeSpot(vehicle, freeFloor);

        ParkingSpot spotOfVehicle = freeFloor.get().assignVehicleToSpot(vehicle, freeSpots);

        ParkingTicket ticket = new ParkingTicket();
        ticket.setTicketNumber(vehicle.getLicenseNumber());
        ticket.setVehicleType(vehicle.getType());
        ticket.setStatus(ParkingTicketStatus.ACTIVE);
        ticket.setFloorName(freeFloor.get().getName());
        ticket.setSpotNumber(spotOfVehicle.getNumber());
        vehicle.assignTicket(ticket);
        this.activeTickets.put(ticket.getTicketNumber(), ticket);

        //ticket.saveInDB();
        // if the ticket is successfully saved in the database, we can increment the parking spot count
        return ticket;
    }

    public synchronized ParkingTicket scanTicket(String licenseNumber, boolean hasTicket) {

        ParkingTicket parkingTicket = findParkingTicket(licenseNumber);

        int totalMinutes = LocalDateTime.now().getMinute() - parkingTicket.getIssuedAt().getMinute();

        parkingRate.setMinutesNumber(totalMinutes);
        parkingRate.setRate(parkingTicket.getVehicleType());

        double amount = parkingRate.bill();
        if (!hasTicket) {
            amount += 100;
            parkingTicket.setStatus(ParkingTicketStatus.LOST);
        }
        parkingTicket.setPayedAmount(amount);
        System.out.println("check ticket from active ticket after setPayedAmount : " + activeTickets.get(licenseNumber));

        return parkingTicket;

    }

    public synchronized boolean getPaymentWithCash(ParkingTicket modifiedParkingTicket, double cashTendered) {

        modifiedParkingTicket.setCashTransaction(new CashTransaction());
        CashTransaction cashTransaction = modifiedParkingTicket.getCashTransaction();

        cashTransaction.setAmount(modifiedParkingTicket.getPayedAmount());
        cashTransaction.setCashTendered(cashTendered);

        boolean transaction = cashTransaction.initiateTransaction();
        if (transaction) {

            cashTransaction.setStatus(PaymentStatus.SUCCESSFUL);
            modifiedParkingTicket.setStatus(ParkingTicketStatus.PAID);
            modifiedParkingTicket.setPayedAt(cashTransaction.getCreationDate());
            payments.put(modifiedParkingTicket.getTicketNumber(), cashTransaction);

            return true;
        } else {
            cashTransaction.setStatus(PaymentStatus.UNSUCCESSFUL);
            return false;
        }

    }

    public synchronized boolean getPaymentWithCard(ParkingTicket modifiedParkingTicket, String nameOnCard) {

        modifiedParkingTicket.setCardTransaction(new CardTransaction());
        CardTransaction cardTransaction = modifiedParkingTicket.getCardTransaction();

        cardTransaction.setNameOnCard(nameOnCard);
        cardTransaction.setAmount(modifiedParkingTicket.getPayedAmount());


        boolean transaction = cardTransaction.initiateTransaction();
        if (transaction) {

            cardTransaction.setStatus(PaymentStatus.SUCCESSFUL);
            modifiedParkingTicket.setStatus(ParkingTicketStatus.PAID);
            modifiedParkingTicket.setPayedAt(cardTransaction.getCreationDate());
            payments.put(modifiedParkingTicket.getTicketNumber(), cardTransaction);

            return true;
        } else {

            cardTransaction.setStatus(PaymentStatus.UNSUCCESSFUL);
            return false;
        }
    }

    private Optional<ParkingFloor> getFirstFreeFloor(Vehicle vehicle) {
        return parkingFloors.values().stream().
                filter(parkingFloor -> !parkingFloor.isWeightOrHeightCapacityOfFloorFull(vehicle.getType())).
                filter(parkingFloor -> !parkingFloor.isAllSpotsFull(vehicle.getType())).
                min(Comparator.comparing(ParkingFloor::getName));
    }

    private List<ParkingSpot> getFirstFreeSpot(Vehicle vehicle, Optional<ParkingFloor> freeFloor) {
        return freeFloor.map(parkingFloor -> parkingFloor.findSpotsToFitVehicle(vehicle)).orElse(null);
    }

    private ParkingTicket findParkingTicket(String licenseNumber) {

        return activeTickets.get(licenseNumber);
    }

    private ParkingFloor findFloorOfVehicle(String licenseNumber) {

        ParkingTicket activeTicket = findParkingTicket(licenseNumber);

        return parkingFloors.get(activeTicket.getFloorName());
    }

    private ParkingSpot findSpotOfVehicle(String licenseNumber) {

        ParkingTicket activeTicket = findParkingTicket(licenseNumber);
        ParkingFloor activeFloor = findFloorOfVehicle(licenseNumber);

        return activeFloor.getSpots().get(activeTicket.getSpotNumber());
    }

    private void unregisterParkingTicket(ParkingTicket parkingTicket) {

        this.activeTickets.remove(parkingTicket.getTicketNumber());
    }

    public boolean isFull(VehicleType type) {

        return parkingFloors.values().stream().
                filter(parkingFloor -> !parkingFloor.isWeightOrHeightCapacityOfFloorFull(type)).
                allMatch(parkingFloor -> parkingFloor.isAllSpotsFull(type));
    }

    public void addParkingFloor(ParkingFloor floor) {
       parkingFloors.put(floor.getName(), floor);
    }

    private void initializeMaxSpots() {

        maxLargeCount = parkingFloors.values().stream().map(f -> f.getLargeSpots().size()).reduce(Integer::sum).orElse(0);
        maxMotorbikeCount = parkingFloors.values().stream().map(f -> f.getMotorbikeSpots().size()).reduce(Integer::sum).orElse(0);
        maxElectricCount = parkingFloors.values().stream().map(f -> f.getElectricSpots().size()).reduce(Integer::sum).orElse(0);
        maxCompactCount = parkingFloors.values().stream().map(f -> f.getCompactSpots().size()).reduce(Integer::sum).orElse(0);
        maxHandicappedCount = parkingFloors.values().stream().map(f -> f.getHandicappedSpots().size()).reduce(Integer::sum).orElse(0);

    }

    private void initializeParkingFloors() {
        this.parkingFloors = new HashMap<>();

        this.parkingFloors.put("1", new ParkingFloor("1", 10000, 3, 1, 1, 1, 1, 1));

        this.parkingFloors.put("2", new ParkingFloor("2", 8000, 2, 1, 1, 1, 1, 1));

        this.parkingFloors.put("3", new ParkingFloor("3", 6000, 2, 1, 1, 1, 1, 1));

        this.parkingFloors.put("4", new ParkingFloor("4", 4000, 3, 1, 1, 1, 1, 1));
    }
    private static ParkingLot parkingLot = null;
    private ParkingLot() {
        // 1. initialize variables: read name, address and parkingRate from database
        this.name = "Ahmad";
        // 2. initialize parking floors: read the parking floor map from database,
        //  this map should tell how many parking spots are there on each floor. This
        //  should also initialize max spot counts too.
        initializeParkingFloors();
        initializeMaxSpots();
        this.numberOfFloors = parkingFloors.size();
        this.parkingAttendantPortal = new ParkingAttendantPortal();
        this.parkingRate = new ParkingRate();
        // 3. initialize parking spot counts by reading all active tickets from database
        // 4. initialize entrance and exit panels: read from database

    }
    public static ParkingLot getInstance() {
        if (parkingLot == null) {
            parkingLot = new ParkingLot();
        }
        return parkingLot;
    }

    public void showEmptySpotNumber() {
        parkingFloors.values().forEach(f -> f.getDisplayBoard().showEmptySpotNumber());

    }

}
