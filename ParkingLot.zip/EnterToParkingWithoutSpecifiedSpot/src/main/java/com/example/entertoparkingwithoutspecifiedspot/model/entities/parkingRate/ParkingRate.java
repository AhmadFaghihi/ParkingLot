package com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingRate;

import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingSpot.ParkingSpotType;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle.VehicleType;
import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
public class ParkingRate {
    private int minutesNumber;
    private double rate;
    public void setRate(VehicleType type) {
        // trucks and vans can only be parked in LargeSpot
        if ((type == VehicleType.TRUCK) || (type == VehicleType.VAN)) {
            if (minutesNumber <= 5) {
                this.rate = ParkingSpotType.LARGE.getRate();
            } else {
                this.rate = ParkingSpotType.LARGE.getRate() + ParkingSpotType.LARGE.getRate() / 2;
            }
        }
        // motorbikes can only be parked at motorbike spots
        if (type == VehicleType.MOTORBIKE) {
            if (minutesNumber <= 5) {
                this.rate = ParkingSpotType.MOTORBIKE.getRate();
            } else {
                this.rate = ParkingSpotType.MOTORBIKE.getRate() + ParkingSpotType.MOTORBIKE.getRate() / 2;
            }
        }
        // cars can be parked at compact or large spots
        if (type == VehicleType.CAR) {
            if (minutesNumber <= 5) {
                this.rate = ParkingSpotType.COMPACT.getRate() + ParkingSpotType.LARGE.getRate() / 2;
            } else {
                this.rate = ParkingSpotType.COMPACT.getRate() + ParkingSpotType.LARGE.getRate() / 2 + ParkingSpotType.COMPACT.getRate() + ParkingSpotType.LARGE.getRate() / 4;
            }
        }
        // electric car can be parked at compact, large or electric spots
        if (type == VehicleType.CAR) {
            this.rate = ParkingSpotType.ELECTRIC.getRate() + ParkingSpotType.LARGE.getRate() + ParkingSpotType.COMPACT.getRate() / 3;
        }

    }
    public double bill(){
        if (minutesNumber<2) return 2;
        return this.minutesNumber*this.rate;
    }
}

