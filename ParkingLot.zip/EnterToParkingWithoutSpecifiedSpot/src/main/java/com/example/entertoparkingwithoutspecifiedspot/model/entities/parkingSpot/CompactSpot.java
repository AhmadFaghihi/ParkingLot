package com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingSpot;

import org.springframework.stereotype.Component;

@Component
public class CompactSpot extends ParkingSpot {

    public CompactSpot() {
        super(ParkingSpotType.COMPACT);
    }

}


