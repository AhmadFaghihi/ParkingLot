package com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingSpot;

import org.springframework.stereotype.Component;

@Component
public class HandicappedSpot extends ParkingSpot {
    public HandicappedSpot() {
        super(ParkingSpotType.HANDICAPPED);

    }

}
