package com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingSpot;

import org.springframework.stereotype.Component;

@Component
public class LargeSpot extends ParkingSpot {

    public LargeSpot() {
        super(ParkingSpotType.LARGE);
    }

}



