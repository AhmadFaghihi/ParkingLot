package com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingSpot;

import org.springframework.stereotype.Component;

@Component
public class MotorbikeSpot extends ParkingSpot {

    public MotorbikeSpot() {
        super(ParkingSpotType.MOTORBIKE);
    }

}



