package com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingSpot;

import com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle.Vehicle;
import lombok.Data;

@Data
public  abstract class ParkingSpot {

    private String number;
    private final ParkingSpotType type;
    private boolean full = false;
    private Vehicle vehicle;

    public ParkingSpot(ParkingSpotType type) {
        this.type = type;
    }

    public boolean isFull() {

        return full;
    }

    public boolean assignVehicle(Vehicle vehicle) {

        this.vehicle = vehicle;
        full = true;
        System.out.println("Assign " + getNumber() + " to " + getVehicle());
        return true;

    }

    public boolean removeVehicle() {
        System.out.println("Free " + getNumber() + " of " + getVehicle());
        this.vehicle = null;
        full = false ;
        return true;
    }

}
