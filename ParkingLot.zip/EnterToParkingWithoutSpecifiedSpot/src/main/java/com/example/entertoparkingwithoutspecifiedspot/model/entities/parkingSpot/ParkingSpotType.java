package com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingSpot;

public enum ParkingSpotType {
     HANDICAPPED(1),ELECTRIC(10),COMPACT(2),  LARGE(4), MOTORBIKE(1);

    private double rate;

    public double getRate() {
        return rate;
    }

    ParkingSpotType() {
    }

    ParkingSpotType(double rate) {
        this.rate = rate;
    }
}
