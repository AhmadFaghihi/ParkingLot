package com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingTicket;

import com.example.entertoparkingwithoutspecifiedspot.model.entities.payment.CardTransaction;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.payment.CashTransaction;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle.VehicleType;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Data
@Component
public class ParkingTicket {

    private String ticketNumber;
    private LocalDateTime issuedAt;
    private LocalDateTime payedAt;

    private double payedAmount;

    private String spotNumber;
    private String floorName;
    private VehicleType vehicleType;

    private ParkingTicketStatus status;
    private CardTransaction cardTransaction;
    private CashTransaction cashTransaction;

    public ParkingTicket() {
        this.issuedAt = LocalDateTime.now();
    }

    }
