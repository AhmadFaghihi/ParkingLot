package com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingTicket;

public enum ParkingTicketStatus {
    ACTIVE, PAID, LOST
}
