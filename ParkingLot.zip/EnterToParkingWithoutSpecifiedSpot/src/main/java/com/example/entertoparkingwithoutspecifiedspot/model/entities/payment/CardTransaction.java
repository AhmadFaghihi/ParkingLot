package com.example.entertoparkingwithoutspecifiedspot.model.entities.payment;

import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingTicket.ParkingTicket;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.HashMap;

@Component
@Data
public class CardTransaction extends Payment {

    private String nameOnCard;
    private double balance=300;
    @Override
    public boolean initiateTransaction() {

        return balance>=getAmount();
    }
}
