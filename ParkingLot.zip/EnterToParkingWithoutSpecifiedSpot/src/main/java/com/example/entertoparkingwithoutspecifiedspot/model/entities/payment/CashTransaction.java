package com.example.entertoparkingwithoutspecifiedspot.model.entities.payment;

import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class CashTransaction extends Payment {
    private double cashTendered;

    @Override
    public boolean initiateTransaction() {
        return cashTendered>=getAmount();
    }
}
