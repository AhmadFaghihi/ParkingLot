package com.example.entertoparkingwithoutspecifiedspot.model.entities.payment;

import lombok.Data;

import java.time.LocalDateTime;

@Data

public abstract class Payment {

    private LocalDateTime creationDate = LocalDateTime.now();
    private double amount;
    private PaymentStatus status;
    public abstract boolean initiateTransaction();
}
