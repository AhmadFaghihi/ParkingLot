package com.example.entertoparkingwithoutspecifiedspot.model.entities.payment;

public enum PaymentStatus {
    SUCCESSFUL, UNSUCCESSFUL
}
