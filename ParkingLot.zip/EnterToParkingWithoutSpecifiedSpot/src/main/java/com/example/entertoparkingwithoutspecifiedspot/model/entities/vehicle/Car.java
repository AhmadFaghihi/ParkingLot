package com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle;

public class Car extends Vehicle {
    public Car(String licenseNumber,VehicleType vehicleType, boolean handicapped) {
        super(licenseNumber,vehicleType,handicapped);
    }

}
