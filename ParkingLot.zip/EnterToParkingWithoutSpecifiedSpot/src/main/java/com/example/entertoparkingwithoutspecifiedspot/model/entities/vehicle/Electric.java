package com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle;

public class Electric extends Vehicle {
    public Electric(String licenseNumber, VehicleType vehicleType,boolean handicapped) {
        super(licenseNumber, vehicleType,handicapped);
    }
}
