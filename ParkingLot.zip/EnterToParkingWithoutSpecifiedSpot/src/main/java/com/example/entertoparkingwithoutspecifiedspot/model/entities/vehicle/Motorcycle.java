package com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle;

public class Motorcycle extends Vehicle {
    public Motorcycle(String licenseNumber, VehicleType vehicleType,boolean handicapped) {
        super(licenseNumber, vehicleType,handicapped);

    }
}
