package com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle;

public class Truck extends Vehicle {
    public Truck(String licenseNumber, VehicleType vehicleType,boolean handicapped) {
        super(licenseNumber,vehicleType,handicapped);
    }
}
