package com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle;

public class Van extends Vehicle {
    public Van(String licenseNumber, VehicleType vehicleType,boolean handicapped) {
        super(licenseNumber, vehicleType,handicapped);
    }
}
