package com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle;

import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingTicket.ParkingTicket;
import lombok.Data;
import org.springframework.stereotype.Component;

@Data

public abstract class Vehicle {

    private final String licenseNumber;

    private boolean handicapped;
    private final VehicleType type;
    private ParkingTicket ticket;

    public Vehicle(String licenseNumber, VehicleType type,boolean handicapped) {
        this.licenseNumber = licenseNumber;
        this.type = type;
        this.handicapped = handicapped;
    }

    public void assignTicket(ParkingTicket ticket) {
        this.ticket = ticket;
    }

}
