package com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle;

public enum VehicleType {
    CAR(2000, 2L),
    TRUCK(4000, 3L),
    ELECTRIC(2000, 2L),
    VAN(3000, 3),
    MOTORBIKE(500, 1L);

    private int weightNeeded;

    private double heightNeeded;




    public int getWeightNeeded() {
        return weightNeeded;
    }

    public double getHeightNeeded() {
        return heightNeeded;
    }



    VehicleType() {
    }

    VehicleType(int weightNeeded, double heightNeeded) {
        this.weightNeeded = weightNeeded;
        this.heightNeeded = heightNeeded;

    }

}

