package com.example.entertoparkingwithoutspecifiedspot.model.exception;

public class ParkingFullException extends Throwable {
}
