package com.example.entertoparkingwithoutspecifiedspot.parking;

import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingTicket.ParkingTicket;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle.Vehicle;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle.VehicleType;

public interface Parking {
    ParkingTicket parkVehicle(String licenseNumber, VehicleType type,boolean handicapped);
    boolean unparkVehicleBtn(ParkingTicket modifiedParkingTicket);
}
