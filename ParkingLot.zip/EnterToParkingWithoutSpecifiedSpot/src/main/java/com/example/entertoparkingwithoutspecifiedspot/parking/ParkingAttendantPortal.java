package com.example.entertoparkingwithoutspecifiedspot.parking;

import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingTicket.ParkingTicket;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.payment.CashTransaction;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.payment.CardTransaction;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.payment.Payment;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle.Vehicle;
import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
public class ParkingAttendantPortal {
    private ParkingTicket parkingTicket;
    private Vehicle vehicle;
    private Payment payment;
    private CashTransaction cashTransaction;
    private CardTransaction cardTransaction;
    private boolean hasTicket;
    private boolean payWithCard;




}
