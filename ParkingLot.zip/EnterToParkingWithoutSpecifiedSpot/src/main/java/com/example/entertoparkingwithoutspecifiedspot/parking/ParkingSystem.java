package com.example.entertoparkingwithoutspecifiedspot.parking;

import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingLot.ParkingLot;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.parkingTicket.ParkingTicket;
import com.example.entertoparkingwithoutspecifiedspot.model.entities.vehicle.*;
import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
public class ParkingSystem implements Parking {

    private ParkingLot parkingLot = ParkingLot.getInstance();

    @Override
    public ParkingTicket parkVehicle(String licenseNumber, VehicleType type, boolean handicapped) {
        if (isFull(type)) {
            throw new RuntimeException("The parking is full! This is why the red light is on!");
        }
        return parkingLot.getNewParkingTicket(getVehicle(licenseNumber, type, handicapped));
    }

    @Override
    public boolean unparkVehicleBtn(ParkingTicket modifiedParkingTicket) {
        return parkingLot.unparkVehicle(modifiedParkingTicket);
    }

    public Vehicle getVehicle(String licenseNumber, VehicleType vehicleType, boolean handicapped) {

        Vehicle vehicle = null;
        switch (vehicleType) {
            case TRUCK -> vehicle = new Truck(licenseNumber, vehicleType, handicapped);
            case VAN -> vehicle = new Van(licenseNumber, vehicleType, handicapped);
            case CAR -> vehicle = new Car(licenseNumber, vehicleType, handicapped);
            case ELECTRIC -> vehicle = new Electric(licenseNumber, vehicleType, handicapped);
            case MOTORBIKE -> vehicle = new Motorcycle(licenseNumber, vehicleType, handicapped);
            default -> System.out.println("Wrong Type");
        }
        return vehicle;
    }

    public void showEmptySpotNumberForEachFloor() {
        parkingLot.showEmptySpotNumber();

    }

    private boolean isFull(VehicleType type) {

        return parkingLot.isFull(type);
    }
}
