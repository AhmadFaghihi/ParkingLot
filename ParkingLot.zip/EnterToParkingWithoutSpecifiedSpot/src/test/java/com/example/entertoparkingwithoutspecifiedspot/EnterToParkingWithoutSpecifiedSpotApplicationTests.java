package com.example.entertoparkingwithoutspecifiedspot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnterToParkingWithoutSpecifiedSpotApplicationTests {

    @Test
    void contextLoads() {
    }

}
